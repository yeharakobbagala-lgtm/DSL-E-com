import { test, expect } from '@playwright/test';
import { loginAsAdmin, TEST_CREDENTIALS } from '../helpers/auth';
import * as path from 'path';

const ARTIFACT_DIR = 'C:/Users/Yehara Kobbagala/.gemini/antigravity/brain/4c1b4457-76fd-4820-8a78-be37fb3a5151';

test.describe('Admin Pen Customization Calibration Studio', () => {
  test('should open visual calibration modal and display interactive controls', async ({ page }) => {
    // 1. Authenticate as Super Admin
    await loginAsAdmin(page, TEST_CREDENTIALS.superAdmin.email, TEST_CREDENTIALS.superAdmin.password);
    await expect(page).toHaveURL(/\/admin\/dashboard/);

    // 2. Navigate to /admin/customize-pen
    await page.goto('/admin/customize-pen');
    await expect(page).toHaveURL(/\/admin\/customize-pen/);

    // 3. Locate Calibrate button in the table
    const calibrateBtn = page.locator('button:has-text("Calibrate")').first();
    await expect(calibrateBtn).toBeVisible({ timeout: 15_000 });
    await calibrateBtn.click();

    // 4. Verify Visual Engraving Calibration modal opens
    const modalHeading = page.locator('h3:has-text("Engraving Zone Calibration")');
    await expect(modalHeading).toBeVisible({ timeout: 10_000 });

    // 5. Verify interactive position tabs and sliders are visible
    const barrelTab = page.locator('button:has-text("BARREL")');
    const capTab = page.locator('button:has-text("CAP")');
    const clipTab = page.locator('button:has-text("CLIP")');
    await expect(barrelTab).toBeVisible();
    await expect(capTab).toBeVisible();
    await expect(clipTab).toBeVisible();

    // 6. Capture high-resolution screenshot for audit deliverable
    const adminShotPath = path.join(ARTIFACT_DIR, 'verified_admin_calibration_modal.png');
    await page.screenshot({ path: adminShotPath, fullPage: false });
    console.log('Saved admin calibration screenshot to:', adminShotPath);
  });
});
